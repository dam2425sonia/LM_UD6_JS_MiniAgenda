// 1️ SELECCIÓN DE ELEMENTOS
const formTarea = document.getElementById('form-tarea');
const inputTarea = document.getElementById('input-tarea');
const listaTareas = document.getElementById('lista-tareas');

// 2️ FUNCIONES DE LÓGICA

function agregarTarea(event) {
    event.preventDefault(); // Evita recargar la página al enviar el formulario

    const texto = inputTarea.value.trim();
    if (texto === "") return; // No agrega tareas vacías

    // Crear elemento li
    const li = document.createElement('li');

    // Crear span para el texto de la tarea (para que no afecte al botón)
    const spanTarea = document.createElement('span');
    spanTarea.textContent = texto;
    spanTarea.style.cursor = 'pointer';

    // Marcar como completada al hacer click en el texto
    spanTarea.addEventListener('click', () => {
        li.classList.toggle('completada');
        /*Aquí está la clave:
            li es el elemento de la lista (por ejemplo, una tarea)
            classList es la lista de clases CSS del elemento
            toggle() hace esto:
                - Si no tiene la clase "completada" → la añade
                - Si ya la tiene → la quita
        */
    });

    li.appendChild(spanTarea);

    // Botón de borrar
    const btnBorrar = document.createElement('button');
    btnBorrar.textContent = "Borrar";
    btnBorrar.classList.add('borrar');
    btnBorrar.addEventListener('click', () => {
        li.remove();
    });

    li.appendChild(btnBorrar);
    listaTareas.appendChild(li);

    // Limpiar input
    inputTarea.value = "";
}

// 3️ ASIGNACIÓN DE EVENTOS
if (formTarea) {
    formTarea.addEventListener('submit', agregarTarea);
}
